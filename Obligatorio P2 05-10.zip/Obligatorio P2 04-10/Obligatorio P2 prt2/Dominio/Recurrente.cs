﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Recurrente : Pago // preguntar como funciona recurrente y unico pq no lo podemso poner el el prevargar
    {
        public DateTime FechaDesde { get; set; }
        public DateTime FechaHasta { get; set; }
        public int Cuotas { get; set; }
        public int CuotasPagas { get; set; }


        public Recurrente (Usuario usu, string descripcion,TipoDeGastos tg, double monto, DateTime inicio, DateTime fin, int cuotas, int cuotasPagas)
            {
            Usuario = usu;
            Descripcion = descripcion;
            TipoDeGasto = tg;
            Monto = monto;
            FechaDesde = inicio;
            FechaHasta = fin ;
            Cuotas = cuotas;
            CuotasPagas = cuotasPagas;

            }
        

        

    }
}
