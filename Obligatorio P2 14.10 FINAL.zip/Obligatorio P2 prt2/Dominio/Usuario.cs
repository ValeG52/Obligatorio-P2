﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Usuario
    {
        private static int ultimoId { get; set; } = 1;

        public int Id {  get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Contrasenia { get; set; }
        public string Email { get; set; }
        public Equipo Equipo { get; set; }
        public DateTime FechaIngreso { get; set; }

        public override string ToString()
        {
            return $"{Nombre} {Apellido}";
        }



        public Usuario()
        {
            Id = ultimoId++;
        }

        public Usuario(string nombre, string apellido, string contrasenia, string email, Equipo equipo)
        {
            Id = ultimoId++;
            Nombre = nombre;
            Apellido = apellido;
            Contrasenia = contrasenia;
            Email = email;
            Equipo = equipo;
        }

        public void Validar()
        {
            if (String.IsNullOrEmpty(Nombre))
            {
                throw new Exception("Nombre vacio");
            }
            if (String.IsNullOrEmpty(Apellido))
            {
                throw new Exception("Apellido vacio");

            }
            if (Contrasenia.Length < 8)
            {
                throw new Exception("Contrasena no valida");
            }
            if (Equipo == null )
            {
                throw new Exception("El usuario debe pertenecer a un equipo");
            }
            

        }
       

    }
}