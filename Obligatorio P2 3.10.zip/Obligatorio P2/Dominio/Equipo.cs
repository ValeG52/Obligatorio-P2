﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Equipo
    {
        private static int _ultimoId = 0;
        public int Id { get; set; }
        public string Nombre { get; set; }
        private List<Usuario> _usuarios = new List<Usuario>();
        public Equipo(string nom)
        {
           Id = _ultimoId++;
           Nombre = nom;
        }
        public List<Usuario> GetIntegrantes()
        {
            return _usuarios;
        }
        public void AgregarUsuarios(Usuario u)
        {
            {
                u.Validar();
                _usuarios.Add(u);
            }
        }
    }
}
