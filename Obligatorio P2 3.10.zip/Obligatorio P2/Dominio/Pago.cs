﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Pago
    {
        private static int _ultimoId = 0;
        public int Id { get; set; }
        public Usuario Usuario { get; set; }
        public string Descripcion { get; set; }
        public double Monto { get; set; }
        public TipoDeGasto TipoDeGasto { get; set; }


        public Pago()
        {
            Id = _ultimoId++;
        }
        public Pago(Usuario us, string descripcion, double monto, TipoDeGasto ts)
        {
            Id = _ultimoId++;
            Usuario = us;
            Descripcion = descripcion;
            Monto = monto;
            TipoDeGasto = ts;
        }






        public double CalcularMontoTotal()
        {

        }



    }
}
