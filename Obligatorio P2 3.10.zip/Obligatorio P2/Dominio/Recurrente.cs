﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Recurrente : Pago
    {
        public DateTime FechaDesde { get; set; }
        public DateTime FechaHasta { get; set; }
        public int Cuotas { get; set; }
        public int CuotasPagas { get; set; }




        public double TotalPagar()
        {

        }

    }
}
