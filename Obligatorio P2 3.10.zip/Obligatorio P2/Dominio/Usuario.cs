﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Usuario
    {
        private static int ultimoId { get; set; } = 1;

        public int Id {  get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Contrasenia { get; set; }
        public string Email { get; set; }
        private List<Equipo> _equipos = new List<Equipo>();
        public DateTime FechaIngreso { get; set; }
        
        

        public Usuario()
        {
            Id = ultimoId++;
        }

        public Usuario(string nombre, string apellido, string contrasenia, string email)
        {
            Id = ultimoId++;
            Nombre = nombre;
            Apellido = apellido;
            Contrasenia = contrasenia;
            Email = email;
        }

        public void Validar()
        {
            if (String.IsNullOrEmpty(Nombre))
            {
                throw new Exception("Nombre vacio");

            }
            if (Contrasenia.Length > 8)
            {
                throw new Exception("Contrasena no valida");
            }
        }
        public string generadorEmail(string nombre, string apellido)
        {
            return nombre+apellido;
        }

    }
}