﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Sistema
    {
        private List<Usuario> _usuarios = new List<Usuario>();
        private List<Equipo> _equipos = new List<Equipo>();
        private List<Pago> _pagos = new List<Pago>();
        private List<TipoDeGastos> _tiposDeGastos = new List<TipoDeGastos>();

        public void PrecargarDatos()
        {
            Usuario usuario1 = new Usuario("Agustin", "Silveira", "agustin1", "agusil@laEmpresa.com");
            Usuario usuario2 = new Usuario("Valentin", "Gonzalez", "vale1234", "valgon@laEmpresa.com");
            Usuario usuario3 = new Usuario("Sofia", "Martinez", "sofi1234", "sofmar@laEmpresa.com");
            Usuario usuario4 = new Usuario("Camila", "Fernandez", "cami1234", "camfer@laEmpresa.com");
            Usuario usuario5 = new Usuario("Joaquin", "Lopez", "joaq1234", "joalop@laEmpresa.com");
            Usuario usuario6 = new Usuario("Mateo", "Pereira", "mate1234", "matper@laEmpresa.com");
            Usuario usuario7 = new Usuario("Lucia", "Rodriguez", "luci1234", "lucrod@laEmpresa.com");
            Usuario usuario8 = new Usuario("Martina", "Torres", "mart1234", "martor@laEmpresa.com");
            Usuario usuario9 = new Usuario("Federico", "Alvarez", "fede1234", "fedalv@laEmpresa.com");
            Usuario usuario10 = new Usuario("Paula", "Suarez", "paul1234", "pausua@laEmpresa.com");
            Usuario usuario11 = new Usuario("Nicolas", "Ramos", "nico1234", "nicram@laEmpresa.com");
            Usuario usuario12 = new Usuario("Florencia", "Gomez", "flor1234", "flogom@laEmpresa.com");
            Usuario usuario13 = new Usuario("Sebastian", "Dominguez", "seba1234", "sebdom@laEmpresa.com");
            Usuario usuario14 = new Usuario("Carolina", "Mendez", "caro1234", "carmen@laEmpresa.com");
            Usuario usuario15 = new Usuario("Diego", "Fernandez", "dieg1234", "diefer@laEmpresa.com");
            Usuario usuario16 = new Usuario("Micaela", "Castro", "mica1234", "miccas@laEmpresa.com");
            Usuario usuario17 = new Usuario("Gonzalo", "Silva", "gonz1234", "gonsil@laEmpresa.com");
            Usuario usuario18 = new Usuario("Bruno", "Cabrera", "brun1234", "brucab@laEmpresa.com");
            Usuario usuario19 = new Usuario("Andrea", "Vazquez", "andr1234", "andvaz@laEmpresa.com");
            Usuario usuario20 = new Usuario("Rodrigo", "Fernandez", "rodr1234", "rodfer@laEmpresa.com");
            Usuario usuario21 = new Usuario("Pablo", "Herrera", "pabl1234", "pabherr@laEmpresa.com");
            Usuario usuario22 = new Usuario("Milagros", "Diaz", "mila1234", "mildia@laEmpresa.com");



            Equipo equipo1 = new Equipo("PowelPeralta");
            Equipo equipo2 = new Equipo("Creature");
            Equipo equipo3 = new Equipo("SantaCruz");
            Equipo equipo4 = new Equipo("Element");


            TipoDeGastos tg1 = new TipoDeGastos("Auto", "Abolladura");
            TipoDeGastos tg2 = new TipoDeGastos("Comida", "Almuerzo de equipo");
            TipoDeGastos tg3 = new TipoDeGastos("Viaje", "Pasaje de avión");
            TipoDeGastos tg4 = new TipoDeGastos("Hospedaje", "Hotel por capacitación");
            TipoDeGastos tg5 = new TipoDeGastos("Tecnología", "Compra de mouse");
            TipoDeGastos tg6 = new TipoDeGastos("Papelería", "Resmas de hojas");
            TipoDeGastos tg7 = new TipoDeGastos("Transporte", "Taxi al cliente");
            TipoDeGastos tg8 = new TipoDeGastos("Mantenimiento", "Reparación de aire acondicionado");
            TipoDeGastos tg9 = new TipoDeGastos("Marketing", "Impresión de folletos");
            TipoDeGastos tg10 = new TipoDeGastos("Capacitación", "Curso online de programación");


            //Pago pago1 = new Pago(usuario22, );

        }


        public List<Usuario> GetClientes()
        {
            return _usuarios;
        }
        public List<Equipo> GetEquipos()
        {
            return _equipos;
        }
    }

public List<Pago> GetPagos()
{
    return _pagos;
}

public void AltaUsuario(Usuario u)
{
    u.Validar();
    _usuarios.Add(u);
}

public void AltaTipoGastos(TipoDeGastos t)
{
    t.Validar();
    _tiposDeGastos.Add(t);
}

public void AltaEquipo(Equipo e)
{
    e.Validar();
    _equipos.Add(e);
}
public void AltaUsuario(Pago p)
{
    p.Validar();
    _pagos.Add(p);
}
    }
}
