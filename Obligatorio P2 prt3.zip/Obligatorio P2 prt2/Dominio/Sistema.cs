﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Sistema
    {
        private List<Usuario> _usuarios = new List<Usuario>();
        private List<Equipo> _equipos = new List<Equipo>();
        private List<Pago> _pagos = new List<Pago>();
        private List<TipoDeGastos> _tiposDeGastos = new List<TipoDeGastos>();

        public Sistema()
        {
            PrecargarDatos();
        }


        public void PrecargarDatos()
        {

            Equipo equipo1 = new Equipo("PowelPeralta");
            Equipo equipo2 = new Equipo("Creature");
            Equipo equipo3 = new Equipo("SantaCruz");
            Equipo equipo4 = new Equipo("Element");

            AltaEquipo(equipo1);
            AltaEquipo(equipo2);
            AltaEquipo(equipo3);
            AltaEquipo(equipo4);

            Usuario usuario1 = new Usuario("Agustin", "Silveira", "agus1234", "agusil@laEmpresa.com", equipo1);
            Usuario usuario2 = new Usuario("Valentin", "Gonzalez", "vale1234", "valgon@laEmpresa.com", equipo2);
            Usuario usuario3 = new Usuario("Sofia", "Martinez", "sofi1234", "sofmar@laEmpresa.com", equipo3);
            Usuario usuario4 = new Usuario("Camila", "Fernandez", "cami1234", "camfer@laEmpresa.com", equipo4);
            Usuario usuario5 = new Usuario("Joaquin", "Lopez", "joaq1234", "joalop@laEmpresa.com", equipo1);
            Usuario usuario6 = new Usuario("Mateo", "Pereira", "mate1234", "matper@laEmpresa.com", equipo2);
            Usuario usuario7 = new Usuario("Lucia", "Rodriguez", "luci1234", "lucrod@laEmpresa.com", equipo3);
            Usuario usuario8 = new Usuario("Martina", "Torres", "mart1234", "martor@laEmpresa.com", equipo4);
            Usuario usuario9 = new Usuario("Federico", "Alvarez", "fede1234", "fedalv@laEmpresa.com", equipo1);
            Usuario usuario10 = new Usuario("Paula", "Suarez", "paul1234", "pausua@laEmpresa.com", equipo2);
            Usuario usuario11 = new Usuario("Nicolas", "Ramos", "nico1234", "nicram@laEmpresa.com", equipo3);
            Usuario usuario12 = new Usuario("Florencia", "Gomez", "flor1234", "flogom@laEmpresa.com", equipo4);
            Usuario usuario13 = new Usuario("Sebastian", "Dominguez", "seba1234", "sebdom@laEmpresa.com", equipo1);
            Usuario usuario14 = new Usuario("Carolina", "Mendez", "caro1234", "carmen@laEmpresa.com", equipo2);
            Usuario usuario15 = new Usuario("Diego", "Fernandez", "dieg1234", "diefer@laEmpresa.com", equipo3);
            Usuario usuario16 = new Usuario("Micaela", "Castro", "mica1234", "miccas@laEmpresa.com", equipo4);
            Usuario usuario17 = new Usuario("Gonzalo", "Silva", "gonz1234", "gonsil@laEmpresa.com", equipo1);
            Usuario usuario18 = new Usuario("Bruno", "Cabrera", "brun1234", "brucab@laEmpresa.com", equipo2);
            Usuario usuario19 = new Usuario("Andrea", "Vazquez", "andr1234", "andvaz@laEmpresa.com", equipo3);
            Usuario usuario20 = new Usuario("Rodrigo", "Fernandez", "rodr1234", "rodfer@laEmpresa.com", equipo4);
            Usuario usuario21 = new Usuario("Pablo", "Herrera", "pabl1234", "pabherr@laEmpresa.com", equipo1);
            Usuario usuario22 = new Usuario("Milagros", "Diaz", "mila1234", "mildia@laEmpresa.com", equipo2);

            AltaUsuario(usuario1);
            AltaUsuario(usuario2);
            AltaUsuario(usuario3);
            AltaUsuario(usuario4);
            AltaUsuario(usuario5);
            AltaUsuario(usuario6);
            AltaUsuario(usuario7);
            AltaUsuario(usuario8);
            AltaUsuario(usuario9);
            AltaUsuario(usuario10);
            AltaUsuario(usuario11);
            AltaUsuario(usuario12);
            AltaUsuario(usuario13);
            AltaUsuario(usuario14);
            AltaUsuario(usuario15);
            AltaUsuario(usuario16);
            AltaUsuario(usuario17);
            AltaUsuario(usuario18);
            AltaUsuario(usuario19);
            AltaUsuario(usuario20);
            AltaUsuario(usuario21);

            TipoDeGastos tg1 = new TipoDeGastos("Auto", "Abolladura");
            TipoDeGastos tg2 = new TipoDeGastos("Comida", "Almuerzo de equipo");
            TipoDeGastos tg3 = new TipoDeGastos("Viaje", "Pasaje de avión");
            TipoDeGastos tg4 = new TipoDeGastos("Hospedaje", "Hotel por capacitación");
            TipoDeGastos tg5 = new TipoDeGastos("Tecnología", "Compra de mouse");
            TipoDeGastos tg6 = new TipoDeGastos("Papelería", "Resmas de hojas");
            TipoDeGastos tg7 = new TipoDeGastos("Transporte", "Taxi al cliente");
            TipoDeGastos tg8 = new TipoDeGastos("Mantenimiento", "Reparación de aire acondicionado");
            TipoDeGastos tg9 = new TipoDeGastos("Marketing", "Impresión de folletos");
            TipoDeGastos tg10 = new TipoDeGastos("Capacitación", "Curso online de programación");

            AltaTipoGastos(tg1);
            AltaTipoGastos(tg2);
            AltaTipoGastos(tg3);
            AltaTipoGastos(tg4);
            AltaTipoGastos(tg5);
            AltaTipoGastos(tg6);
            AltaTipoGastos(tg7);
            AltaTipoGastos(tg8);
            AltaTipoGastos(tg9);
            AltaTipoGastos(tg10);




            Recurrente rec1 = new Recurrente(usuario1, "Suscripción Netflix", tg2, 500, new DateTime(2025, 1, 1), new DateTime(2025, 6, 1), 6, 2);
            Recurrente rec2 = new Recurrente(usuario2, "Internet oficina", tg7, 1500, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 3);
            Recurrente rec3 = new Recurrente(usuario3, "Suscripción Spotify", tg2, 300, new DateTime(2025, 2, 1), new DateTime(2025, 7, 1), 6, 1);
            Recurrente rec4 = new Recurrente(usuario4, "Gimnasio", tg9, 1200, new DateTime(2025, 1, 15), new DateTime(2025, 12, 15), 12, 5);
            Recurrente rec5 = new Recurrente(usuario5, "Software de diseño", tg8, 2000, new DateTime(2025, 1, 1), new DateTime(2025, 6, 1), 6, 2);
            Recurrente rec6 = new Recurrente(usuario6, "Suscripción Adobe", tg8, 2500, new DateTime(2025, 2, 1), new DateTime(2025, 12, 1), 11, 4);
            Recurrente rec7 = new Recurrente(usuario7, "Agua y luz oficina", tg7, 800, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 6);
            Recurrente rec8 = new Recurrente(usuario8, "Cafetería mensual", tg3, 400, new DateTime(2025, 1, 5), new DateTime(2025, 12, 5), 12, 3);
            Recurrente rec9 = new Recurrente(usuario9, "Suscripción Amazon Prime", tg2, 450, new DateTime(2025, 3, 1), new DateTime(2025, 8, 1), 6, 2);
            Recurrente rec10 = new Recurrente(usuario10, "Suscripción Office 365", tg8, 1800, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 4);
            Recurrente rec11 = new Recurrente(usuario11, "Transporte mensual", tg5, 900, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 7);
            Recurrente rec12 = new Recurrente(usuario12, "Membresía gimnasio", tg9, 1300, new DateTime(2025, 2, 1), new DateTime(2025, 11, 1), 10, 3);
            Recurrente rec13 = new Recurrente(usuario13, "Servicios limpieza", tg7, 700, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 5);
            Recurrente rec14 = new Recurrente(usuario14, "Capacitación online", tg6, 2500, new DateTime(2025, 3, 1), new DateTime(2025, 8, 1), 6, 1);
            Recurrente rec15 = new Recurrente(usuario15, "Suscripción Canva", tg8, 600, new DateTime(2025, 1, 15), new DateTime(2025, 12, 15), 12, 6);
            Recurrente rec16 = new Recurrente(usuario16, "Teléfono móvil", tg7, 900, new DateTime(2025, 2, 1), new DateTime(2025, 12, 1), 11, 4);
            Recurrente rec17 = new Recurrente(usuario17, "Netflix", tg2, 500, new DateTime(2025, 1, 1), new DateTime(2025, 6, 1), 6, 2);
            Recurrente rec18 = new Recurrente(usuario18, "Spotify", tg2, 300, new DateTime(2025, 2, 1), new DateTime(2025, 7, 1), 6, 1);
            Recurrente rec19 = new Recurrente(usuario19, "Suscripción software contable", tg8, 2200, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 5);
            Recurrente rec20 = new Recurrente(usuario20, "Servicios internet", tg7, 1500, new DateTime(2025, 1, 1), new DateTime(2025, 12, 1), 12, 3);
            Recurrente rec21 = new Recurrente(usuario21, "Cafetería oficina", tg3, 400, new DateTime(2025, 1, 5), new DateTime(2025, 12, 5), 12, 3);

            AltaPago(rec1);
            AltaPago(rec2);
            AltaPago(rec3);
            AltaPago(rec4);
            AltaPago(rec5);
            AltaPago(rec6);
            AltaPago(rec7);
            AltaPago(rec8);
            AltaPago(rec9);
            AltaPago(rec10);
            AltaPago(rec11);
            AltaPago(rec12);
            AltaPago(rec13);
            AltaPago(rec14);
            AltaPago(rec15);
            AltaPago(rec16);
            AltaPago(rec17);
            AltaPago(rec18);
            AltaPago(rec19);
            AltaPago(rec20);
            AltaPago(rec21);

            Unico uni1 = new Unico(usuario1, "Pago almuerzo equipo", tg3, 1200, 2001, new DateTime(2025, 1, 5));
            Unico uni2 = new Unico(usuario2, "Carga de combustible", tg1, 2800, 2002, new DateTime(2025, 1, 7));
            Unico uni3 = new Unico(usuario3, "Compra café oficina", tg3, 450, 2003, new DateTime(2025, 1, 10));
            Unico uni4 = new Unico(usuario4, "Entrada evento corporativo", tg10, 3200, 2004, new DateTime(2025, 1, 12));
            Unico uni5 = new Unico(usuario5, "Pago taxi reunión", tg5, 700, 2005, new DateTime(2025, 1, 15));
            Unico uni6 = new Unico(usuario6, "Compra material oficina", tg4, 2500, 2006, new DateTime(2025, 1, 18));
            Unico uni7 = new Unico(usuario7, "Pago estacionamiento", tg5, 500, 2007, new DateTime(2025, 1, 20));
            Unico uni8 = new Unico(usuario8, "Almuerzo con clientes", tg3, 1900, 2008, new DateTime(2025, 1, 22));
            Unico uni9 = new Unico(usuario9, "Compra tinta impresora", tg4, 1200, 2009, new DateTime(2025, 1, 25));
            Unico uni10 = new Unico(usuario10, "Pago Uber oficina", tg5, 800, 2010, new DateTime(2025, 1, 28));
            Unico uni11 = new Unico(usuario11, "Cena de trabajo", tg3, 1500, 2011, new DateTime(2025, 2, 1));
            Unico uni12 = new Unico(usuario12, "Compra libros capacitación", tg6, 2200, 2012, new DateTime(2025, 2, 3));
            Unico uni13 = new Unico(usuario13, "Pago limpieza oficina extra", tg7, 900, 2013, new DateTime(2025, 2, 5));
            Unico uni14 = new Unico(usuario14, "Entrada conferencia online", tg6, 2700, 2014, new DateTime(2025, 2, 7));
            Unico uni15 = new Unico(usuario15, "Almuerzo interno", tg3, 1300, 2015, new DateTime(2025, 2, 10));
            Unico uni16 = new Unico(usuario16, "Compra accesorios computadora", tg8, 3500, 2016, new DateTime(2025, 2, 12));
            Unico uni17 = new Unico(usuario17, "Pago café empresa", tg3, 600, 2017, new DateTime(2025, 2, 15));
            Unico uni18 = new Unico(usuario18, "Entrada taller presencial", tg6, 2500, 2018, new DateTime(2025, 2, 18));
            Unico uni19 = new Unico(usuario19, "Pago estacionamiento largo plazo", tg5, 1200, 2019, new DateTime(2025, 2, 20));
            Unico uni20 = new Unico(usuario20, "Compra snacks oficina", tg3, 800, 2020, new DateTime(2025, 2, 22));
            Unico uni21 = new Unico(usuario21, "Pago taxi aeropuerto", tg5, 950, 2021, new DateTime(2025, 2, 25));


            AltaPago(uni1);
            AltaPago(uni2);
            AltaPago(uni3);
            AltaPago(uni4);
            AltaPago(uni5);
            AltaPago(uni6);
            AltaPago(uni7);
            AltaPago(uni8);
            AltaPago(uni9);
            AltaPago(uni10);
            AltaPago(uni11);
            AltaPago(uni12);
            AltaPago(uni13);
            AltaPago(uni14);
            AltaPago(uni15);
            AltaPago(uni16);
            AltaPago(uni17);
            AltaPago(uni18);
            AltaPago(uni19);
            AltaPago(uni20);
            AltaPago(uni21);

        }


        public List<Usuario> GetClientes()
        {
            return _usuarios;
        }
        public List<Equipo> GetEquipos()
        {
            return _equipos;
        }


        public List<Pago> GetPagos()
        {
            return _pagos;
        }


        public void AltaUsuario(Usuario u)
        {
            u.Validar();
            _usuarios.Add(u);
        }

        public void AltaTipoGastos(TipoDeGastos t)
        {
            t.Validar();
            _tiposDeGastos.Add(t);
        }

        public void AltaEquipo(Equipo e)
        {
            e.Validar();
            _equipos.Add(e);
        }
        public void AltaPago(Pago p)
        {
            _pagos.Add(p);
        }

        public List<Pago> GetPagosByEmail(string email)
        {
            List<Pago> pagosDelUsuario = new List<Pago>();

            foreach (Pago p in _pagos)
            {
                if (p.Usuario != null && p.Usuario.Email == email)
                {
                    pagosDelUsuario.Add(p);
                }
            }

            return pagosDelUsuario;
        }
    }
}
