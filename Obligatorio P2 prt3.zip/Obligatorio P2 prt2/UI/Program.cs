﻿using Dominio;


namespace UI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Sistema s = new Sistema();
           
            int op = -1;
            
            while (op != 0)
            {
                Console.Clear();
                Console.WriteLine("1 - Ver usuarios registrados");
                Console.WriteLine("2 - Ver equipos");
                Console.WriteLine("3 - Total de gastos");
                Console.WriteLine("4 - Pagos segun email");
                Console.WriteLine("0 - Salir");




                op = int.Parse(Console.ReadLine());

                if (op.Equals(1))
                {
                    
                    foreach (Usuario u in s.GetClientes())
                    {
                        Console.WriteLine($"{u.Nombre} - {u.Apellido} - {u.Email} - {u.Equipo}");

                    }
                    Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                    Console.ReadKey();
                }
                else if (op.Equals(2))
                {
                    
                    foreach (Equipo e in s.GetEquipos())
                    {
                        Console.WriteLine($"{e.Nombre}"); 
                    }
                    Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                }else if (op.Equals(3))
                {
                    foreach (Pago p in s.GetPagos())
                    {
                        Console.WriteLine($"{p.Usuario} - {p.Descripcion} - ${p.Monto} - {p.TipoDeGasto}");
                    }
                    Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                }
                Console.ReadKey();

            }

        }
    }
}
