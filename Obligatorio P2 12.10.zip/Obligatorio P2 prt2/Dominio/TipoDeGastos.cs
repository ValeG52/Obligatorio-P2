﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class TipoDeGastos
    {
        private static int _ultimoId = 0;
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }

        public override string ToString()
        {
            return $"{Nombre} {Descripcion}";
        }

        public TipoDeGastos()
        {
            Id = _ultimoId++;
        }
        public TipoDeGastos(string nom, string des)
        {
            Id = _ultimoId++;
            Nombre = nom;
            Descripcion = des;
        }

        public void Validar()
        {
            if (String.IsNullOrEmpty(Nombre))
            {
                throw new Exception("Nombre vacio");

            }
            if (String.IsNullOrEmpty(Descripcion))
            {
                throw new Exception("Descripcion vacia");

            }

        }


    }
}
