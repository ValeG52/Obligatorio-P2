﻿using Dominio;


namespace UI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Sistema s = new Sistema();
           
            int op = -1;
            
            while (op != 0)
            {
                Console.Clear();
                Console.WriteLine("1 - Ver usuarios registrados");
                Console.WriteLine("2 - Obtener pagos de usario por email");
                Console.WriteLine("3 - Dar de alta un usuario");
                Console.WriteLine("4 - Encontrar miembros de equipo");
                Console.WriteLine("0 - Salir");




                op = int.Parse(Console.ReadLine());

                if (op.Equals(1))
                {
                    
                    foreach (Usuario u in s.GetClientes())
                    {
                        Console.WriteLine($"{u.Nombre} - {u.Email} - {u.Equipo}");

                    }
                    Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                    Console.ReadKey();
                }
                else if (op.Equals(2))
                {
                    Console.WriteLine("Escriba un email:");
                    string email = Console.ReadLine();
                    List<Pago> pagos = s.GetPagosByEmail(email);
                    
                    foreach (Pago p in pagos)
                    {
                        Console.WriteLine($"{p}"); 
                    }
                    
                    Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                
                }
                
                else if (op.Equals(3))
                {
                    Console.WriteLine("Escriba su nombre:");
                    string nom = Console.ReadLine();

                    Console.WriteLine("Escriba su apellido:");
                    string ape = Console.ReadLine();

                    Console.WriteLine("Escriba uns contrasenia:");
                    string pas = Console.ReadLine();

                    string mail =  s.GenerarEmail(nom, ape);

                    Console.WriteLine("Elija un equipo:");
                    Console.WriteLine("1 - PowelPeralta");
                    Console.WriteLine("2 - Creature");
                    Console.WriteLine("3 - SantaCruz");
                    Console.WriteLine("4 - Element");
                    

                    int equipo = int.Parse(Console.ReadLine());

                    Equipo eq = s.BuscarEquipo(equipo);




                    Usuario usuario = new Usuario(nom, ape, pas, mail, eq);
                   s.AltaUsuario(usuario);








                    Console.WriteLine("--------------Presiona una tecla para volver al menú--------------");
                }
                Console.ReadKey();

            }

        }
    }
}
