﻿using Dominio;


namespace UI
{
    internal class Program
    {
        static void Main(string[] args)
        {
           Sistema s = new Sistema();

            int op = -1;

            while(op != 0)
            {
                Console.WriteLine("1 - Ver usuarios registrados");


                op = int.Parse(Console.ReadLine());

                if (op.Equals(1))
                {
                    foreach (Usuario u in s.GetClientes())
                    {
                        Console.WriteLine($"{u.Nombre} - {u.Apellido} - {u.Email}");

                    }
                }



            }

            


        }
    }
}
