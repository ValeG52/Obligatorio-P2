﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Equipo
    {
        private static int _ultimoId = 1;
        public int Id { get; set; }
        public string Nombre { get; set; }
        //private List<Usuario> _usuarios = new List<Usuario>(); preguntar si esta bienllevar una lista 
        public Equipo(string nom)
        {
           Id = _ultimoId++;
           Nombre = nom;
        }
        public List<Usuario> GetIntegrantes()
        {
            return _usuarios;
        }


        // public void AgregarUsuarios(Usuario u) preguntar donde se agregan los ususarios a la lista de equipo 
        // {
        //     {
        //         u.Validar();
        //         _usuarios.Add(u);
        //     }
        // }

        public void Validar()
        {
            if (String.IsNullOrEmpty(Nombre))
            {
                throw new Exception("El nombre del equipo no puede estar vacio");

            }
            if (Nombre.Length < 3)
            {
                throw new Exception("El nombre del equipo debe tener al menos 3 caracteres");

            }

        }

    }
}
