﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Sistema
    {
        private List<Usuario> _usuarios = new List<Usuario>();
        private List<Equipo> _equipos = new List<Equipo>();
        private List<Pago> _pagos = new List<Pago>();
        private List<TipoDeGastos> _tiposDeGastos = new List<TipoDeGastos>();

        public void PrecargarDatos()
        {

            Equipo equipo1 = new Equipo("PowelPeralta");
            Equipo equipo2 = new Equipo("Creature");
            Equipo equipo3 = new Equipo("SantaCruz");
            Equipo equipo4 = new Equipo("Element");

            AltaEquipo(equipo1);
            AltaEquipo(equipo2);
            AltaEquipo(equipo3);
            AltaEquipo(equipo4);

            Usuario usuario1 = new Usuario("Agustin", "Silveira", "agusil@laEmpresa.com", equipo1);
            Usuario usuario2 = new Usuario("Valentin", "Gonzalez", "valgon@laEmpresa.com", equipo1);
            Usuario usuario3 = new Usuario("Sofia", "Martinez", "sofmar@laEmpresa.com", equipo2);
            Usuario usuario4 = new Usuario("Camila", "Fernandez", "camfer@laEmpresa.com", equipo2);
            Usuario usuario5 = new Usuario("Joaquin", "Lopez", "joalop@laEmpresa.com", equipo3);
            Usuario usuario6 = new Usuario("Mateo", "Pereira", "matper@laEmpresa.com", equipo3);
            Usuario usuario7 = new Usuario("Lucia", "Rodriguez", "lucrod@laEmpresa.com", equipo4);
            Usuario usuario8 = new Usuario("Martina", "Torres", "martor@laEmpresa.com", equipo4);
            Usuario usuario9 = new Usuario("Federico", "Alvarez", "fedalv@laEmpresa.com", equipo1);
            Usuario usuario10 = new Usuario("Paula", "Suarez", "pausua@laEmpresa.com", equipo1);
            Usuario usuario11 = new Usuario("Nicolas", "Ramos", "nicram@laEmpresa.com", equipo2);
            Usuario usuario12 = new Usuario("Florencia", "Gomez", "flogom@laEmpresa.com", equipo2);
            Usuario usuario13 = new Usuario("Sebastian", "Dominguez", "sebdom@laEmpresa.com", equipo3);
            Usuario usuario14 = new Usuario("Carolina", "Mendez", "carmen@laEmpresa.com", equipo3);
            Usuario usuario15 = new Usuario("Diego", "Fernandez", "diefer@laEmpresa.com", equipo4);
            Usuario usuario16 = new Usuario("Micaela", "Castro", "miccas@laEmpresa.com", equipo4);
            Usuario usuario17 = new Usuario("Gonzalo", "Silva", "gonsil@laEmpresa.com", equipo1);
            Usuario usuario18 = new Usuario("Bruno", "Cabrera", "brucab@laEmpresa.com", equipo2);
            Usuario usuario19 = new Usuario("Andrea", "Vazquez", "andvaz@laEmpresa.com", equipo3);
            Usuario usuario20 = new Usuario("Rodrigo", "Fernandez", "rodfer@laEmpresa.com", equipo4);
            Usuario usuario21 = new Usuario("Pablo", "Herrera", "pabherr@laEmpresa.com", equipo1);
            Usuario usuario22 = new Usuario("Milagros", "Diaz", "mildia@laEmpresa.com", equipo2);

    
            AltaUsuario(usuario1);
            AltaUsuario(usuario2);
            AltaUsuario(usuario3);
            AltaUsuario(usuario4);
            AltaUsuario(usuario5);
            AltaUsuario(usuario6);
            AltaUsuario(usuario7);
            AltaUsuario(usuario8);
            AltaUsuario(usuario9);
            AltaUsuario(usuario10);
            AltaUsuario(usuario11);
            AltaUsuario(usuario12);
            AltaUsuario(usuario13);
            AltaUsuario(usuario14);
            AltaUsuario(usuario15);
            AltaUsuario(usuario16);
            AltaUsuario(usuario17);
            AltaUsuario(usuario18);
            AltaUsuario(usuario19);
            AltaUsuario(usuario20);
            AltaUsuario(usuario21);


            



            TipoDeGastos tg1 = new TipoDeGastos("Auto", "Abolladura");
            TipoDeGastos tg2 = new TipoDeGastos("Comida", "Almuerzo de equipo");
            TipoDeGastos tg3 = new TipoDeGastos("Viaje", "Pasaje de avión");
            TipoDeGastos tg4 = new TipoDeGastos("Hospedaje", "Hotel por capacitación");
            TipoDeGastos tg5 = new TipoDeGastos("Tecnología", "Compra de mouse");
            TipoDeGastos tg6 = new TipoDeGastos("Papelería", "Resmas de hojas");
            TipoDeGastos tg7 = new TipoDeGastos("Transporte", "Taxi al cliente");
            TipoDeGastos tg8 = new TipoDeGastos("Mantenimiento", "Reparación de aire acondicionado");
            TipoDeGastos tg9 = new TipoDeGastos("Marketing", "Impresión de folletos");
            TipoDeGastos tg10 = new TipoDeGastos("Capacitación", "Curso online de programación");


            //Pago pago1 = new Pago(usuario22, );

        }


        public List<Usuario> GetClientes()
        {
            return _usuarios;
        }
        public List<Equipo> GetEquipos()
        {
            return _equipos;
        }
    }

public List<Pago> GetPagos()
{
    return _pagos;
}

public void AltaUsuario(Usuario u)
{
    u.Validar();
    _usuarios.Add(u);
}

public void AltaTipoGastos(TipoDeGastos t)
{
    t.Validar();
    _tiposDeGastos.Add(t);
}

public void AltaEquipo(Equipo e)
{
    e.Validar();
    _equipos.Add(e);
}
public void AltaPago(Pago p)
{
    p.Validar();
    _pagos.Add(p);
}
    }
}
